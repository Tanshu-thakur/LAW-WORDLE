# Law Wordle
A legal-themed Wordle-style game for law students and lawyers.